#include "MENU.h"

void gotoxy(short x ,short y){
	COORD pos = {x,y};
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}
void MENU :: MAIN_MENU(void)
{
    char ch ;
    LINES L ;
    L.CLEARUP() ;
    while (1)
    {
        system("cls");
        gotoxy(14,3);
        cout<<"     C++ Project for Payroll Management System";
        L.BOX(25,7,57,9,218) ;
        L.BOX(10,5,71,21,218) ;
        L.BOX(11,6,70,20,219) ;
        gotoxy(29,8) ;
        cout <<"PAYROLL MANAGEMENT SYSTEM" ;
        gotoxy(30,11) ;
        cout <<"1: New employee" ;
        gotoxy(30,12) ;
        cout <<"2: Display employee" ;
        gotoxy(30,13) ;
        cout <<"3: List of employees" ;
        gotoxy(30,14) ;
        cout <<"4: Salary slip" ;
        gotoxy(30,15) ;
        cout <<"5: Edit" ;
        gotoxy(30,16) ;
        cout <<"0: Quit" ;
        gotoxy(30,18) ;
        cout <<"Enter your choice :" ;
        gotoxy(5,23);

        ch = getch() ;
        if (ch == 27 || ch == '0')
            break ;
        else if (ch == '1')
        {
            employee E ;
            E.NEW_employee() ;
        }
        else if (ch == '2')
        {
            employee E ;
            E.DISPLAY() ;
        }
        else if (ch == '3')
        {
            employee E ;
        }
        else if (ch == '4')
        {
            employee E ;
            E.SALARY_SLIP() ;
        }
        else if (ch == '5')
            EDIT_MENU() ;
    }
    L.CLEARUP() ;
	system("cls");
}
void MENU :: EDIT_MENU(void)
{
	system("cls");
    char ch ;
    LINES L ;
    L.CLEARDOWN() ;
    while (1)
    {
        L.BOX(28,8,49,10,218) ;
        L.BOX(10,5,71,21,218) ;
        L.BOX(11,6,70,20,219) ;
        gotoxy(31,9) ;
        cout <<"E D I T  M E N U" ;
        gotoxy(30,13) ;
        cout <<"1: DELETE RECORD" ;
        gotoxy(30,14) ;
        cout <<"2: MODIFY RECORD" ;
        gotoxy(30,15) ;
        cout <<"0: EXIT" ;
        gotoxy(30,17) ;
        cout <<"ENTER YOUR CHOICE :" ;
        ch = getch() ;
        if (ch == 27 || ch == '0')
            break ;
        else if (ch == '1')
        {
            employee E ;
            E.DELETION() ;
        }
        else if (ch == '2')
        {
            employee E ;
            E.MODIFICATION() ;
        }
    }
    L.CLEARDOWN();
	system("cls");
}
void LINES :: LINE_HOR(int column1, int column2, int row, char c)
{
    for ( column1; column1<=column2; column1++ )
    {
        gotoxy(column1,row) ;
        cout <<c ;
    }
}
void LINES :: LINE_VER(int row1, int row2, int column, char c)
{
    for ( row1; row1<=row2; row1++ )
    {
        gotoxy(column,row1) ;
        cout <<c ;
    }
}
void LINES :: BOX(int column1, int row1, int column2, int row2, char c)
{
    char ch=218 ;
    char c1, c2, c3, c4 ;
    char l1=196, l2=179 ;
    if (c == ch)
    {
        c1=218 ;
        c2=191 ;
        c3=192 ;
        c4=217 ;
        l1 = 196 ;
        l2 = 179 ;
    }
    else
    {
        c1=c ;
        c2=c ;
        c3=c ;
        c4=c ;
        l1 = c ;
        l2 = c ;
    }
    gotoxy(column1,row1) ;
    cout <<c1 ;
    gotoxy(column2,row1) ;
    cout <<c2 ;
    gotoxy(column1,row2) ;
    cout <<c3 ;
    gotoxy(column2,row2) ;
    cout <<c4 ;
    column1++ ;
    column2-- ;
    LINE_HOR(column1,column2,row1,l1) ;
    LINE_HOR(column1,column2,row2,l1) ;
    column1-- ;
    column2++ ;
    row1++ ;
    row2-- ;
    LINE_VER(row1,row2,column1,l2) ;
    LINE_VER(row1,row2,column2,l2) ;
}
void LINES :: CLEARUP(void)
{
    for (int i=25; i>=1; i--)
    {
		for (int z=0; z<20; z++);
        gotoxy(1,i) ;
		getch();         
    }
}
void LINES :: CLEARDOWN(void)
{
    for (int i=1; i<=25; i++)
    {
        for (int y=0; y<20; y++);;
        gotoxy(1,i) ;      
    }
}
void employee :: ADD_RECORD(int ecode, char ename[30], char eaddress[30], char ephone[10], int d, int m, int y, char edesig[15], char egrade, char ehouse, char econv, float eloan, float ebasic)
{
    fstream file ;
    file.open("employee.DAT", ios::app) ;
    code = ecode ;
    strcpy(name,ename) ;
    strcpy(address,eaddress) ;
    strcpy(phone,ephone) ;
    dd = d ;
    mm = m ;
    yy = y ;
    strcpy(desig,edesig) ;
    grade = egrade ;
    house = ehouse ;
    convense = econv ;
    loan = eloan ;
    basic = ebasic ;
    file.write((char *) this, sizeof(employee)) ;
    file.close() ;
}
void employee :: MODIFY_RECORD(int ecode, char ename[26], char eaddress[31], char ephone[10], char edesig[16], char egrade, char ehouse, char econv, float eloan, float ebasic)
{
    int recno ;
    recno = RECORDNO(ecode) ;
    fstream file ;
    file.open("employee.DAT", ios::out | ios::ate) ;
    strcpy(name,ename) ;
    strcpy(address,eaddress) ;
    strcpy(phone,ephone) ;
    strcpy(desig,edesig) ;
    grade = egrade ;
    house = ehouse ;
    convense = econv ;
    loan = eloan ;
    basic = ebasic ;
    int location ;
    location = (recno-1) * sizeof(employee) ;
    file.seekp(location) ;
    file.write((char *) this, sizeof(employee)) ;
    file.close() ;
}
void employee :: DELETE_RECORD(int ecode)
{
    fstream file ;
    file.open("employee.DAT", ios::in) ;
    fstream temp ;
    temp.open("temp.dat", ios::out) ;
    file.seekg(0,ios::beg) ;
    while (!file.eof())
    {
        file.read((char *) this, sizeof(employee)) ;
        if (file.eof())
            break ;
        if (code != ecode)
            temp.write((char *) this, sizeof(employee)) ;
    }
    file.close() ;
    temp.close() ;
    file.open("employee.DAT", ios::out) ;
    temp.open("temp.dat", ios::in) ;
    temp.seekg(0,ios::beg) ;
    while (!temp.eof())
    {
        temp.read((char *) this, sizeof(employee)) ;
        if ( temp.eof() )
            break ;
        file.write((char *) this, sizeof(employee)) ;
    }
    file.close() ;
    temp.close() ;
}
int employee :: LASTCODE(void)
{
    fstream file ;
    file.open("employee.DAT", ios::in) ;
    file.seekg(0,ios::beg) ;
    int count=0 ;
    while (file.read((char *) this, sizeof(employee)))
        count = code ;
    file.close() ;
    return count ;
}
int employee :: RECORDNO(int ecode)
{
    fstream file ;
    file.open("employee.DAT", ios::in) ;
    file.seekg(0,ios::beg) ;
    int recno=0 ;
    while (file.read((char *) this, sizeof(employee)))
    {
        recno++ ;
        if (code == ecode)
            break ;
    }
    file.close() ;
    return recno ;
}
void employee :: DISPLAY_RECORD(int ecode)
{
    fstream file ;
    file.open("employee.DAT", ios::in) ;
    file.seekg(0,ios::beg) ;
    while (file.read((char *) this, sizeof(employee)))
    {
        if (code == ecode)
        {
            gotoxy(5,5) ;
            cout <<"employee Code # " <<code ;
            gotoxy(5,6) ;
            cout <<"-------------" ;
            gotoxy(5,7) ;
            cout <<"Name         : " <<name ;
            gotoxy(5,8) ;
            cout <<"Address      : " <<address ;
            gotoxy(5,9) ;
            cout <<"Phone no.    : " <<phone ;
            gotoxy(5,11) ;
            cout <<"JOINING DATE" ;
            gotoxy(5,12) ;
            cout <<"------------" ;
            gotoxy(5,13) ;
            cout <<"Day   : " <<dd ;
            gotoxy(5,14) ;
            cout <<"Month : " <<mm ;
            gotoxy(5,15) ;
            cout <<"Year  : " <<yy ;
            gotoxy(5,17) ;
            cout <<"Designation  : " <<desig ;
            gotoxy(5,18) ;
            cout <<"Grade        : " <<grade ;
            if (grade != 'E')
            {
                gotoxy(5,19) ;
                cout <<"House (y/n)    : " <<house ;
                gotoxy(5,20) ;
                cout <<"Convense (y/n) : " <<convense ;
                gotoxy(5,22) ;
                cout <<"Basic Salary   : " <<basic ;
            }
            gotoxy(5,21) ;
            cout <<"Loan           : " <<loan ;
        }
    }
    file.close() ;
}
void employee :: NEW_employee(void)
{
     
    char  ch, egrade, ehouse='N', econv='N' ;
    char  ename[26], eaddress[31], ephone[10], edesig[16], t1[10] ;
    float t2=0.0, eloan=0.0, ebasic=0.0 ;
    int   d, m, y, ecode, valid ;
    gotoxy(72,2) ;
    cout <<"<0>=EXIT" ;
    gotoxy(28,3) ;
    cout <<"ADDITION OF NEW employee" ;
    gotoxy(5,5) ;
    cout <<"employee Code # " ;
    gotoxy(5,6) ;
    cout <<"-------------" ;
    gotoxy(5,7) ;
    cout <<"Name         : " ;
    gotoxy(5,8) ;
    cout <<"Address      : " ;
    gotoxy(5,9) ;
    cout <<"Phone no.    : " ;
    gotoxy(5,11) ;
    cout <<"JOINING DATE" ;
    gotoxy(5,12) ;
    cout <<"------------" ;
    gotoxy(5,13) ;
    cout <<"Day   : " ;
    gotoxy(5,14) ;
    cout <<"Month : " ;
    gotoxy(5,15) ;
    cout <<"Year  : " ;
    gotoxy(5,17) ;
    cout <<"Designation  : " ;
    gotoxy(5,18) ;
    cout <<"Grade        : " ;
    gotoxy(5,21) ;
    cout <<"Loan           : " ;

    ecode = LASTCODE() + 1 ;
    if (ecode == 1)
    {
        ADD_RECORD(ecode, "null", "null", "null", 0, 0, 0, "null", 'n', 'n', 'n', 0.0, 0.0) ;
        DELETE_RECORD(ecode) ;
    }
    gotoxy(21,5) ;
    cout <<ecode ;
    do
    {
        valid = 1 ;
        gotoxy(5,25) ;
         
        cout <<"Enter the name of the employee" ;
        gotoxy(20,7) ;
         
        gets(ename) ;
        strupr(ename) ;
        if (ename[0] == '0')
            return ;
        if (strlen(ename) < 1 || strlen(ename) > 25)
        {
            valid = 0 ;
            gotoxy(5,25) ;
             
            cout <<"\7Enter correctly (Range: 1..25)" ;
            getch() ;
        }
    }
    while (!valid) ;
    do
    {
        valid = 1 ;
        gotoxy(5,25) ;
         
        cout <<"Enter Address of the employee" ;
        gotoxy(20,8) ;
         
        gets(eaddress) ;
        strupr(eaddress) ;
        if (eaddress[0] == '0')
            return ;
        if (strlen(eaddress) < 1 || strlen(eaddress) > 30)
        {
            valid = 0 ;
            gotoxy(5,25) ;
             
            cout <<"\7Enter correctly (Range: 1..30)" ;
            getch() ;
        }
    }
    while (!valid) ;
    do
    {
        valid = 1 ;
        gotoxy(5,25) ;
         
        cout <<"Enter Phone no. of the employee or Press <ENTER> for none" ;
        gotoxy(20,9) ;
         
        gets(ephone) ;
        if (ephone[0] == '0')
            return ;
        if ((strlen(ephone) < 7 && strlen(ephone) > 0) || (strlen(ephone) > 9))
        {
            valid = 0 ;
            gotoxy(5,25) ;
             
            cout <<"Enter correctly" ;
            getch() ;
        }
    }
    while (!valid) ;
    if (strlen(ephone) == 0)
        strcpy(ephone,"-") ;
    char tday[3], tmonth[3], tyear[5] ;
    int td ;
    do
    {
        valid = 1 ;
        do
        {
            gotoxy(5,25) ;
             
            cout <<"ENTER DAY OF JOINING" ;
            gotoxy(13,13) ;
             
            gets(tday) ;
            td = atoi(tday) ;
            d = td ;
            if (tday[0] == '0')
                return ;
        }
        while (d == 0) ;
        do
        {
            gotoxy(5,25) ;
             
            cout <<"ENTER MONTH OF JOINING" ;
            gotoxy(13,14) ;
             
            gets(tmonth) ;
            td = atoi(tmonth) ;
            m = td ;
            if (tmonth[0] == '0')
                return ;
        }
        while (m == 0) ;
        do
        {
            gotoxy(5,25) ;
             
            cout <<"ENTER YEAR OF JOINING" ;
            gotoxy(13,15) ;
             
            gets(tyear) ;
            td = atoi(tyear) ;
            y = td ;
            if (tyear[0] == '0')
                return ;
        }
        while (y == 0) ;
        if (d>31 || d<1)
            valid = 0 ;
        else if (((y%4)!=0 && m==2 && d>28) || ((y%4)==0 && m==2 && d>29))
            valid = 0 ;
        else if ((m==4 || m==6 || m==9 || m==11) && d>30)
            valid = 0 ;
        else if (y<1990 || y>2020)
            valid = 0 ;
        if (!valid)
        {
            valid = 0 ;
            gotoxy(5,25) ;
             
            cout <<"Enter correctly" ;
            getch() ;
            gotoxy(13,14) ;
             
            gotoxy(13,15) ;
             
        }
    }
    while (!valid) ;
    do
    {
        valid = 1 ;
        gotoxy(5,25) ;
         
        cout <<"Enter Designation of the employee" ;
        gotoxy(20,17) ;
         
        gets(edesig) ;
        strupr(edesig) ;
        if (edesig[0] == '0')
            return ;
        if (strlen(edesig) < 1 || strlen(edesig) > 15)
        {
            valid = 0 ;
            gotoxy(5,25) ;
             
            cout <<"Enter correctly (Range: 1..15)" ;
            getch() ;
        }
    }
    while (!valid) ;
    do
    {
        gotoxy(5,25) ;
         
        cout <<"Enter Grade of the employee (A,B,C,D,E)" ;
        gotoxy(20,18) ;
         
        egrade = getche() ;
        egrade = toupper(egrade) ;
        if (egrade == '0')
            return ;
    }
    while (egrade < 'A' || egrade > 'E') ;
    if (egrade != 'E')
    {
        gotoxy(5,19) ;
        cout <<"House (y/n)    : " ;
        gotoxy(5,20) ;
        cout <<"Convense (y/n) : " ;
        gotoxy(5,22) ;
        cout <<"Basic Salary   : " ;
        do
        {
            gotoxy(5,25) ;
             
            cout <<"ENTER IF HOUSE ALLOWANCE IS ALLOTED TO employee OR NOT" ;
            gotoxy(22,19) ;
             
            ehouse = getche() ;
            ehouse = toupper(ehouse) ;
            if (ehouse == '0')
                return ;
        }
        while (ehouse != 'Y' && ehouse != 'N') ;
        do
        {
            gotoxy(5,25) ;
             
            cout <<"ENTER IF CONVENCE ALLOWANCE IS ALLOTED TO employee OR NOT" ;
            gotoxy(22,20) ;
             
            econv = getche() ;
            econv = toupper(econv) ;
            if (econv == '0')
                return ;
        }
        while (econv != 'Y' && econv != 'N') ;
    }
    do
    {
        valid = 1 ;
        gotoxy(5,25) ;
         
        cout <<"ENTER LOAN AMOUNT IF ISSUED" ;
        gotoxy(22,21) ;         
        gets(t1) ;
        t2 = atof(t1) ;
        eloan = t2 ;
        if (eloan > 50000)
        {
            valid = 0 ;
            gotoxy(5,25) ;       
            cout <<"SHOULD NOT BE GREATER THAN 50000" ;
            getch() ;
        }
    }
    while (!valid) ;
    if (egrade != 'E')
    {
        do
        {
            valid = 1 ;
            gotoxy(5,25) ;    
            cout <<"ENTER BASIC SALARY OF THE Employee" ;
            gotoxy(22,22) ;  
            gets(t1) ;
            t2 = atof(t1) ;
            ebasic = t2 ;
            if (t1[0] == '0')
                return ;
            if (ebasic > 50000)
            {
                valid = 0 ;
                gotoxy(5,25) ;
                 
                cout <<"\7SHOULD NOT GREATER THAN 50000" ;
                getch() ;
            }
        }
        while (!valid) ;
    }
    gotoxy(5,25) ;
    do
    {
        gotoxy(5,24) ; 
        cout <<"Do you want to save (y/n) " ;
        ch = getche() ;
        ch = toupper(ch) ;
        if (ch == '0')
            return ;
    }
    while (ch != 'Y' && ch != 'N') ;
    if (ch == 'N')
        return ;
    ADD_RECORD(ecode, ename, eaddress, ephone, d, m, y, edesig, egrade, ehouse, econv, eloan, ebasic) ;
}
void employee :: DISPLAY(void)
{
    char t1[10] ;
    int t2, ecode ;
    gotoxy(72,2) ;
    cout <<"<0>=EXIT" ;
    gotoxy(5,5) ;
    cout <<"Enter code of the employee  " ;
    gets(t1) ;
    t2 = atoi(t1) ;
    ecode = t2 ;
    if (ecode == 0)
        return ;
    DISPLAY_RECORD(ecode) ;
    gotoxy(5,25) ;
    cout <<"Press any key to continue..." ;
    getch() ;
}
void employee :: MODIFICATION(void)
{
    char  ch, egrade, ehouse='N', econv='N' ;
    char  ename[26], eaddress[31], ephone[10], edesig[16], t1[10] ;
    float t2=0.0, eloan=0.0, ebasic=0.0 ;
    int   ecode, valid ;
    gotoxy(72,2) ;
    cout <<"<0>=EXIT" ;
    gotoxy(5,5) ;
    cout <<"Enter code of the employee  " ;
    gets(t1) ;
    t2 = atoi(t1) ;
    ecode = t2 ;
    if (ecode == 0)
        return ;
    gotoxy(72,2) ;
    cout <<"<0>=EXIT" ;
    gotoxy(22,3) ;
    cout <<"MODIFICATION OF THE employee RECORD" ;
    DISPLAY_RECORD(ecode) ;
    do
    {
        gotoxy(5,24) ;
         
        cout <<"Do you want to modify this record (y/n) " ;
        ch = getche() ;
        ch = toupper(ch) ;
        if (ch == '0')
            return ;
    }
    while (ch != 'Y' && ch != 'N') ;
    if (ch == 'N')
        return ;
     
    fstream file ;
    file.open("employee.DAT", ios::in) ;
    file.seekg(0,ios::beg) ;
    while (file.read((char *) this, sizeof(employee)))
    {
        if (code == ecode)
            break ;
    }
    file.close() ;
    gotoxy(5,5) ;
    cout <<"Employee Code # " <<ecode ;
    gotoxy(5,6) ;
    cout <<"-------------" ;
    gotoxy(40,5) ;
    cout <<"JOINING DATE : " ;
    gotoxy(40,6) ;
    cout <<"--------------" ;
    gotoxy(55,5) ;
    cout <<dd <<"/" <<mm <<"/" <<yy ;
    gotoxy(5,7) ;
    cout <<"Name         : " ;
    gotoxy(5,8) ;
    cout <<"Address      : " ;
    gotoxy(5,9) ;
    cout <<"Phone no.    : " ;
    gotoxy(5,10) ;
    cout <<"Designation  : " ;
    gotoxy(5,11) ;
    cout <<"Grade        : " ;
    gotoxy(5,14) ;
    cout <<"Loan           : " ;
    do
    {
        valid = 1 ;
        gotoxy(5,25) ;
         
        cout <<"Enter the name of the employee or <ENTER> FOR NO CHANGE" ;
        gotoxy(20,7) ;
         
        gets(ename) ;
        strupr(ename) ;
        if (ename[0] == '0')
            return ;
        if (strlen(ename) > 25)
        {
            valid = 0 ;
            gotoxy(5,25) ;
             
            cout <<"\7Enter correctly (Range: 1..25)" ;
            getch() ;
        }
    }
    while (!valid) ;
    if (strlen(ename) == 0)
    {
        strcpy(ename,name) ;
        gotoxy(20,7) ;
        cout <<ename ;
    }
    do
    {
        valid = 1 ;
        gotoxy(5,25) ;
         
        cout <<"Enter Address of the employee or <ENTER> FOR NO CHANGE" ;
        gotoxy(20,8);         
        gets(eaddress);
        strupr(eaddress) ;
        if (eaddress[0] == '0')
            return ;
        if (strlen(eaddress) > 30)
        {
            valid = 0 ;
            gotoxy(5,25);
            cout <<"\7Enter correctly (Range: 1..30)" ;
            getch() ;
        }
    }
    while (!valid) ;
    if (strlen(eaddress) == 0)
    {
        strcpy(eaddress,address) ;
        gotoxy(20,8) ;
        cout <<eaddress ;
    }
    do
    {
        valid = 1 ;
        gotoxy(5,25);         
        cout <<"Enter Phone no. of the employee or or <ENTER> FOR NO CHANGE" ;
        gotoxy(20,9);         
        gets(ephone);
        if (ephone[0] == '0')
            return ;
        if ((strlen(ephone) < 7 && strlen(ephone) > 0) || (strlen(ephone) > 9))
        {
            valid = 0 ;
            gotoxy(5,25);             
            cout <<"\7Enter correctly" ;
            getch() ;
        }
    }
    while (!valid) ;
    if (strlen(ephone) == 0)
    {
        strcpy(ephone,phone) ;
        gotoxy(20,9) ;
        cout <<ephone ;
    }
    do
    {
        valid = 1 ;
        gotoxy(5,25);         
        cout <<"Enter Designation of the employee or <ENTER> FOR NO CHANGE" ;
        gotoxy(20,10) ;         
        gets(edesig) ;
        strupr(edesig) ;
        if (edesig[0] == '0')
            return ;
        if (strlen(edesig) > 15)
        {
            valid = 0 ;
            gotoxy(5,25);             
            cout <<"\7Enter correctly (Range: 1..15)" ;
            getch() ;
        }
    }
    while (!valid) ;
    if (strlen(edesig) == 0)
    {
        strcpy(edesig,desig) ;
        gotoxy(20,10) ;
        cout <<edesig ;
    }
    do
    {
        gotoxy(5,25) ;         
        cout <<"Enter Grade of the employee (A,B,C,D,E) or <ENTER> FOR NO CHANGE" ;
        gotoxy(20,11);         
        egrade = getche() ;
        egrade = toupper(egrade) ;
        if (egrade == '0')
            return ;
        if (egrade == 13)
        {
            egrade = grade ;
            gotoxy(20,11) ;
            cout <<grade ;
        }
    }
    while (egrade < 'A' || egrade > 'E') ;
    if (egrade != 'E')
    {
        gotoxy(5,12) ;
        cout <<"House (y/n)    : " ;
        gotoxy(5,13) ;
        cout <<"Convense (y/n) : " ;
        gotoxy(5,15) ;
        cout <<"Basic Salary   : " ;
        do
        {
            gotoxy(5,25) ;             
            cout <<"ALLOTED HOUSE ALLOWANCE ? or <ENTER> FOR NO CHANGE" ;
            gotoxy(22,12) ;             
            ehouse = getche() ;
            ehouse = toupper(ehouse) ;
            if (ehouse == '0')
                return ;
            if (ehouse == 13)
            {
                ehouse = house ;
                gotoxy(22,12) ;
                cout <<ehouse ;
            }
        }
        while (ehouse != 'Y' && ehouse != 'N') ;
        do
        {
            gotoxy(5,25) ;             
            cout <<"ALLOTED CONVENCE ALLOWANCE or <ENTER> FOR NO CHANGE" ;
            gotoxy(22,13) ;             
            econv = getche() ;
            econv = toupper(econv) ;
            if (econv == '0')
                return ;
            if (econv == 13)
            {
                econv = convense ;
                gotoxy(22,13) ;
                cout <<econv ;
            }
        }
        while (econv != 'Y' && econv != 'N') ;
    }
    do
    {
        valid = 1 ;
        gotoxy(5,25) ;         
        cout <<"ENTER LOAN AMOUNT or <ENTER> FOR NO CHANGE" ;
        gotoxy(22,14) ;         
        gets(t1) ;
        t2 = atof(t1) ;
        eloan = t2 ;
        if (eloan > 50000)
        {
            valid = 0 ;
            gotoxy(5,25) ;             
            cout <<"\7SHOULD NOT GREATER THAN 50000" ;
            getch() ;
        }
    }
    while (!valid) ;
    if (strlen(t1) == 0)
    {
        eloan = loan ;
        gotoxy(22,14) ;
        cout <<eloan ;
    }
    if (egrade != 'E')
    {
        do
        {
            valid = 1 ;
            gotoxy(5,25) ;             
            cout <<"ENTER BASIC SALARY or <ENTER> FOR NO CHANGE" ;
            gotoxy(22,15) ;             
            gets(t1) ;
            t2 = atof(t1) ;
            ebasic = t2 ;
            if (t1[0] == '0')
                return ;
            if (ebasic > 50000)
            {
                valid = 0 ;
                gotoxy(5,25) ;                 
                cout <<"\7SHOULD NOT GREATER THAN 50000" ;
                getch() ;
            }
        }
        while (!valid) ;
        if (strlen(t1) == 0)
        {
            ebasic = basic ;
            gotoxy(22,15) ;
            cout <<ebasic ;
        }
    }
    gotoxy(5,25) ;     
    do
    {
        gotoxy(5,18) ;         
        cout <<"Do you want to save (y/n) " ;
        ch = getche() ;
        ch = toupper(ch) ;
        if (ch == '0')
            return ;
    }
    while (ch != 'Y' && ch != 'N') ;
    if (ch == 'N')
        return ;
    MODIFY_RECORD(ecode,ename,eaddress,ephone,edesig,egrade,ehouse,econv,eloan,ebasic) ;
    gotoxy(5,23) ;
    cout <<"\7Record Modified" ;
    gotoxy(5,25) ;
    cout <<"Press any key to continue..." ;
    getch() ;
}
void employee :: DELETION(void)
{    
    char t1[10], ch ;
    int t2, ecode ;
    gotoxy(72,2) ;
    cout <<"<0>=EXIT" ;
    gotoxy(5,5) ;
    cout <<"Enter code of the employee  " ;
    gets(t1) ;
    t2 = atoi(t1) ;
    ecode = t2 ;
    if (ecode == 0)
        return ;
    gotoxy(72,2) ;
    cout <<"<0>=EXIT" ;
    gotoxy(24,3) ;
    cout <<"DELETION OF THE employee RECORD" ;
    DISPLAY_RECORD(ecode) ;
    do
    {
        gotoxy(5,24) ;
         
        cout <<"Do you want to delete this record (y/n) " ;
        ch = getche() ;
        ch = toupper(ch) ;
        if (ch == '0')
            return ;
    }
    while (ch != 'Y' && ch != 'N') ;
    if (ch == 'N')
        return ;
    DELETE_RECORD(ecode) ;
    LINES L ;
    L.CLEARDOWN() ;
    gotoxy(5,23) ;
    cout <<"\7Record Deleted" ;
    gotoxy(5,25) ;
    cout <<"Press any key to continue..." ;
    getch() ;
}
int employee :: VALID_DATE(int d1, int m1, int y1)
{
    int valid=1 ;
    if (d1>31 || d1<1)
        valid = 0 ;
    else if (((y1%4)!=0 && m1==2 && d1>28) || ((y1%4)==0 && m1==2 && d1>29))
        valid = 0 ;
    else if ((m1==4 || m1==6 || m1==9 || m1==11) && d1>30)
        valid = 0 ;
    return valid ;
}
void employee :: SALARY_SLIP(void)
{
    char t1[10] ;
    int t2, ecode, valid ;
    gotoxy(72,2) ;
    cout <<"<0>=EXIT" ;
    gotoxy(5,5) ;
    cout <<"Enter code of the employee  " ;
    gets(t1) ;
    t2 = atoi(t1) ;
    ecode = t2 ;
    if (ecode == 0)
        return ;
    fstream file ;
    file.open("employee.DAT", ios::in) ;
    file.seekg(0,ios::beg) ;
    while (file.read((char *) this, sizeof(employee)))
    {
        if (code == ecode)
            break ;
    }
    file.close() ;
    int d1, m1, y1 ;
    char *mon[12]= {"January","February","March","April","May","June","July","August","September","November","December"} ;
    LINES L ;
    L.BOX(2,1,79,25,219) ;
    gotoxy(31,2) ;
    L.LINE_HOR(3,78,3,196) ;
    gotoxy(34,4) ;
    cout <<"SALARY SLIP" ;
    gotoxy(60,4) ;
    cout <<"Date: " <<d1 <<"/" <<m1 <<"/" <<y1 ;
    gotoxy(34,5) ;
    cout <<mon[m1-1] <<", " <<y1 ;
    L.LINE_HOR(3,78,6,196) ;
    gotoxy(6,7) ;
    cout <<"employee Name : " <<name ;
    gotoxy(6,8) ;
    cout <<"Designation   : " <<desig ;
    gotoxy(67,8) ;
    cout <<"Grade : " <<grade ;
    L.BOX(6,9,75,22,218) ;
    L.LINE_HOR(10,71,20,196) ;
    int days, hours ;
    if (grade == 'E')
    {
        do
        {
            valid = 1 ;
            gotoxy(10,21) ;
            cout <<"ENTER NO. OF DAYS WORKED IN THE MONTH " ;
            gotoxy(10,11) ;
            cout <<"No. of Days   : " ;
            gets(t1) ;
            t2 = atof(t1) ;
            days = t2 ;
            if (!VALID_DATE(days,m1,y1))
            {
                valid = 0 ;
                gotoxy(10,21) ;
                cout <<"\7ENTER CORRECTLY                       " ;
                getch() ;
                gotoxy(10,11) ;
                cout <<"                    " ;
            }
        }
        while (!valid) ;
        do
        {
            valid = 1 ;
            gotoxy(10,21) ;
            cout <<"ENTER NO. OF HOURS WORKED OVER TIME   " ;
            gotoxy(10,13) ;
            cout <<"No. of hours  : " ;
            gets(t1) ;
            t2 = atof(t1) ;
            hours = t2 ;
            if (hours > 8 || hours < 0)
            {
                valid = 0 ;
                gotoxy(10,21) ;
                cout <<"\ENTER CORRECTLY            " ;
                getch() ;
                gotoxy(10,13) ;
                cout <<"                    " ;
            }
        }
        while (!valid) ;
        gotoxy(10,21) ;
        cout <<"                                               " ;
        gotoxy(10,11) ;
        cout <<"                        " ;
        gotoxy(10,13) ;
        cout <<"                        " ;
    }
    gotoxy(10,10) ;
    cout <<"Basic Salary         : NGN." ;
    gotoxy(10,12) ;
    cout <<"ALLOWANCE" ;
    if (grade != 'E')
    {
        gotoxy(12,13) ;
        cout <<"HRA  : NGN." ;
        gotoxy(12,14) ;
        cout <<"CA   : NGN" ;
        gotoxy(12,15) ;
        cout <<"DA   : NGN" ;
    }
    else
    {
        gotoxy(12,13) ;
        cout <<"OT   : NGN" ;
    }
    gotoxy(10,17) ;
    cout <<"DEDUCTIONS" ;
    gotoxy(12,18) ;
    cout <<"LD   : NGN" ;
    if (grade != 'E')
    {
        gotoxy(12,19) ;
        cout <<"PF   : NGN" ;
    }
    gotoxy(10,21) ;
    cout <<"NET SALARY           : NGN" ;
    gotoxy(6,24) ;
    cout <<"CASHIER" ;
    gotoxy(68,24) ;
    cout <<"employee" ;
    float HRA=0.0, CA=0.0, DA=0.0, PF=0.0, LD=0.0, OT=0.0, allowance, deduction, netsalary ;
    if (grade != 'E')
    {
        if (house == 'Y')
            HRA = (5*basic)/100 ;
        if (convense == 'Y')
            CA  = (2*basic)/100 ;
        DA  = (5*basic)/100 ;
        PF  = (2*basic)/100 ;
        LD  = (15*loan)/100 ;
        allowance = HRA+CA+DA ;
        deduction = PF+LD ;
    }
    else
    {
        basic = days * 30 ;
        LD  = (15*loan)/100 ;
        OT  = hours * 10 ;
        allowance = OT ;
        deduction = LD ;
    }
    netsalary = (basic+allowance)-deduction ;
    gotoxy(36,10) ;
    cout <<basic ;
    if (grade != 'E')
    {
        gotoxy(22,13) ;
        cout <<HRA ;
        gotoxy(22,14) ;
        cout <<CA ;
        gotoxy(22,15) ;
        cout <<DA ;
        gotoxy(22,19) ;
        cout <<PF ;
    }
    else
    {
        gotoxy(22,13) ;
        cout <<OT ;
    }
    gotoxy(22,18) ;
    cout <<LD ;
    gotoxy(33,15) ;
    cout <<"NGN" <<allowance ;
    gotoxy(33,19) ;
    cout <<"NGN" <<deduction ;
    gotoxy(36,21) ;
    cout <<netsalary ;
    gotoxy(2,1) ;
    getch() ;
}
