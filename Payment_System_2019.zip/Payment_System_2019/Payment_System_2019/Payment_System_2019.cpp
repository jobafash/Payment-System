#include <iostream>
#include <fstream>
#include <process.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <conio.h>
#include <dos.h>
#include <windows.h>
#include <algorithm>
#include "MENU.h"
using namespace std;

int main()
{
    MENU menu ;
    menu.MAIN_MENU() ;
	system("pause");
}